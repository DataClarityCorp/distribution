#!/usr/bin/env bash

WORKING_DIR=k8s

cd ${WORKING_DIR}

kubectl delete deployment -l solution=dataclarity-platform
kubectl delete service -l solution=dataclarity-platform
kubectl delete secret -l solution=dataclarity-platform
kubectl delete configmap -l solution=dataclarity-platform
kubectl delete ingress -l solution=dataclarity-platform
kubectl delete statefulset -l solution=dataclarity-platform

read -p "Remove persistent storage [y/n] : " REMOVE_PERSISTENT_STORAGE
if [[ ${REMOVE_PERSISTENT_STORAGE} = "y" ]]; then
  kubectl delete pvc -l solution=dataclarity-platform
  if [[ -f persistent/postgres.yaml ]]; then
    read -p "Remove postgres data [y/n] : " REMOVE_PG_DATA
    if [[ ${REMOVE_PG_DATA} = "y" ]]; then
      kubectl delete -f persistent/postgres.yaml
    fi
  fi
fi

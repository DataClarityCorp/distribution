DataClarity Analytics Installation Guide

Please find the latest installation guide at:
https://support.dataclaritycorp.com/hc/en-us/sections/4410214920596-Install-using-Kubernetes-recommended-

Step 1. Install snap

Snap is a prerequisite software for installing DataClarity platform.
Note: Snap might already be available on your system. Depending on your Linux distribution, snap can already be installed. For example, Ubuntu has snap integrated, but you need to install it for Red Hat.

For details, see the respective online documentation at: https://snapcraft.io/docs/installing-snapd

The following steps are the example for Red Hat Enterprise Linux (RHEL)/CentOS:

Procedure:

- Add the repository for the Extra Packages for Enterprise Linux to your system:
sudo yum -y install epel-release

- Install snap:
sudo yum -y install snapd

- Enable the systemd unit that manages the main snap communication socket:
sudo systemctl enable --now snapd.socket

- To enable classic snap support, create a symbolic link between /var/lib/snapd/snap and /snap:
sudo ln -s /var/lib/snapd/snap /snap

- To ensure snap’s paths are updated correctly, either log out and back in again, or restart your system.

---

Step 2. Install MicroK8s

MicroK8s is a small, fast, secure, single-node Kubernetes that can be installed on a Linux box.
For details, see MicroK8s documentation at https://microk8s.io/docs/

Procedure:

- Install MicroK8s:
sudo snap install microk8s --classic --channel=1.19/stable

- Alias microk8s.kubectl to kubectl:
sudo snap alias microk8s.kubectl kubectl

- Add your username to the microk8s group, as well as allow it to access the .kube folder from your home directory:
sudo usermod -a -G microk8s <username>
sudo chown -f -R <username> ~/.kube

Note: Replace <username> with your actual username.

- To ensure the changes are applied correctly, either log out and back in again, or restart your system.

- Enable the necessary Microk8s add-ons:
microk8s.enable dashboard
microk8s.enable dns
microk8s.enable ingress
microk8s.enable storage

---

Step 3. Install DataClarity

Before you install

- Ensure that you prepare a clean environment (VM) with no other 3rd party software installed, apart from snap/MicroK8s that have been installed earlier.
- Ensure the system requirements for platform installation are met:
https://support.dataclaritycorp.com/hc/en-us/articles/4410214954772-System-requirements
- Obtain the distribution file, <dataclarity>.tar.gz, provided by DataClarity.
- Obtain the license script provided by DataClarity.
- By default, the platform uses a self-signed certificate, generated during the installation, which is why it's recommended that your version of OpenSSL is 1.1.1 or higher. If you want to use your own certificates, create the certs folder inside of <dataclarity>\template, and copy over your .crt and .key files to <dataclarity>\template\certs, and rename them to cert.crt and cert.key. If your .key file is encrypted, you will have to unencrypt it.
- Update firewall rules to ensure that ports 80, 443, and 5432 are open, and permit traffic between the VM and the host using the iptables command:
  Ubuntu:
    sudo ufw allow 80
    sudo ufw allow 443
    sudo ufw allow 5432
    sudo ufw default allow routed
    sudo iptables -P FORWARD ACCEPT
    sudo apt-get install iptables-persistent
  RHEL/CentOS:
    sudo firewall-cmd --zone=public --add-port=80/tcp --permanent
	sudo firewall-cmd --zone=public --add-port=443/tcp --permanent
	sudo firewall-cmd --zone=public --add-port=5432/tcp --permanent
	sudo firewall-cmd --zone=public --add-masquerade --permanent
	sudo firewall-cmd --reload

Procedure:

- Unpack the tar file:
tar -zxf <dataclarity>.tar.gz

- If the install, remove and the system check scripts are not already executable, change their mode, if needed:
chmod +x install.sh remove.sh system_check.sh

- Execute the installation script:
./install.sh

- Enter the public entry point (IP, host, FQDN)
  Note: If you set an IP address, the installation script will skip the next step for adding an alias, as it will not be necessary.

- For Add host alias to resolve “[hostname]”, enter one of the following:
  y — If you want to use your PC hostname that is not registered in public DNS (not bound to that PC on the global DNS server). This command will add the PC’s hostname and IP to the hosts file inside the docker containers. For IP address for “hostname”, type in the external IP by which you can reach the PC outside the machine.
  n — To skip adding host alias.

- For Disable authentication for Kubernetes Dashboard, select one of the following:
  y — To disable authentication for the Kubernetes Dashboard; it is not recommended if you are using a public entry point.
  n — To use authentication for the Kubernetes Dashboard. You will need to use a token to log into the Kubernetes Dashboard. If you choose this option, the access token will be displayed at the end of the installation process.

- The next and final step will start the installation process, which will take around 10-20 min, depending on your system resources and internet connection speed.

Step 4. Accessing the application

- Use the URL provided at the end of the installation to access the DataClarity application in your browser: https://hostname/home

- Log in using the default credentials, admin / admin; you will be required to change your password on the first login.

- From the homepage, open Access Manager; go to Users; click View all users; click on the ID of the admin user; go to Role Mappings; select all Available Roles, and click Add selected; return to the homepage, and reload the page; you now have full access.

- To create additional local users, please follow this guide:
https://support.dataclaritycorp.com/hc/en-us/articles/4408968725780-Add-a-user

- For more details on configuring different authentication types, as well as managing users, please see:
https://support.dataclaritycorp.com/hc/en-us/sections/4404011613716-Manage-users

- In order to access different guides, or to contact us, please go to our support portal:
https://support.dataclaritycorp.com/hc/en-us

Thank you for choosing DataClarity.

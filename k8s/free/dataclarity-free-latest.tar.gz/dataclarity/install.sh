#!/usr/bin/env bash

WORKING_DIR=k8s
KP=$(openssl rand -base64 12)

KV=$(kubectl version | grep v1.19 | cut -d " " -f4 | sort -u)
KM='Minor:"19+",'

HOST=$(hostname)
IP=$(ip route get 8.8.8.8 | grep -oP 'src \K[^ ]+')

if [ "$KV" != "$KM" ]; then
        echo "An unsupported version of Microk8s is installed. The required version is 1.19"
		exit 1
fi

echo -e "\n-- $(date)" >> config.txt

if [[ -f template/secret/user-access.txt ]]; then
  sed -i "s/!aMa_DCadm!N;)/${KP}/g" template/secret/user-access.txt
  kubectl create secret generic --dry-run=client -o yaml --from-env-file=template/secret/user-access.txt user-access > template/secret/user-access.yaml
  rm template/secret/user-access.txt
  echo "dcadmin=${KP}" >> config.txt
  DCPWD=true
else
  DCPWD=false
fi

rm -rf ${WORKING_DIR}
mkdir ${WORKING_DIR}

cp -r template/. ${WORKING_DIR}

cd ${WORKING_DIR} || exit

replace_text() {
  find . -type f -exec sed -i "s/$1/$2/g" {} +
}
replace_variable() {
  replace_text "\$$1" $2
}

replace_variable BUILD_LABEL "\"`date +%m%d%Y_%H%M%S`\""

replace_variable REGISTRY "gcr.io"

replace_variable IMAGE_TAG "latest-2023.5"

echo ""
read -p "Enter the public entry point (IP, host, FQDN) (Default: ${HOST}): " PUBLIC_ENTRYPOINT
PUBLIC_ENTRYPOINT=${PUBLIC_ENTRYPOINT:-$HOST}
echo "PUBLIC_ENTRYPOINT=${PUBLIC_ENTRYPOINT}" >> ../config.txt
PUBLIC_ENTRYPOINT_IS_IP_ADDRESS=false
if [[ ${PUBLIC_ENTRYPOINT} =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
  PUBLIC_ENTRYPOINT_IS_IP_ADDRESS=true
fi

if [[ ${PUBLIC_ENTRYPOINT_IS_IP_ADDRESS} = false ]]; then
  echo ""
  echo "Add host alias to resolve \"$PUBLIC_ENTRYPOINT\" ? [y/n] (Default: n)"
  read -rp "Adds an entry to the containers' hosts file resolving the host/domain. Needed when using a local domain. " ADD_HOST_ALIAS
  if [[ ${ADD_HOST_ALIAS} = "y" ]]; then
    echo ""
	read -rp "Enter the IP address for \"$PUBLIC_ENTRYPOINT\" (Default: ${IP}): " ALIAS_IP_ADDRESS
	ALIAS_IP_ADDRESS=${ALIAS_IP_ADDRESS:-$IP}
    replace_text '      containers:' '      hostAliases:\n      - ip: "$ALIAS_IP_ADDRESS"\n        hostnames:\n        - "$PUBLIC_ENTRYPOINT"\n      containers:'
  fi
fi

if [[ ! -f certs/cert.crt ]]; then
  echo ""
    echo "No SSL Certificate provided. Creating Self-Signed SSL Certificate..."
    mkdir -p certs
    if [[ ${PUBLIC_ENTRYPOINT_IS_IP_ADDRESS} = true ]]; then
      CERT_SAN="IP:$PUBLIC_ENTRYPOINT"
    else
      CERT_SAN="DNS:$PUBLIC_ENTRYPOINT"
    fi
    openssl req -x509 -nodes -days 36500 -newkey rsa:2048 -subj "/CN=$PUBLIC_ENTRYPOINT/O=$PUBLIC_ENTRYPOINT" --addext "subjectAltName=$CERT_SAN" -keyout certs/cert.key -out certs/cert.crt
	cp -r certs ../template/certs
fi

replace_variable DATASERVER_PUBLIC_ENTRYPOINT_PORT "5432"
replace_variable DATASERVER_PUBLIC_ENTRYPOINT ${PUBLIC_ENTRYPOINT}
replace_variable PUBLIC_ENTRYPOINT ${PUBLIC_ENTRYPOINT}
replace_variable ALIAS_IP_ADDRESS ${ALIAS_IP_ADDRESS}

if [[ -f deployment/postgres.yaml ]]; then
  replace_variable DB_SERVER_ADDRESS "postgres"
else
  echo ""
  read -rp "Enter the Postgres server address: " DB_SERVER_ADDRESS
  replace_variable DB_SERVER_ADDRESS ${DB_SERVER_ADDRESS}
  echo "DB_SERVER_ADDRESS=${DB_SERVER_ADDRESS}" >> ../config.txt
fi

replace_variable DB_NAME_SUFFIX "db"

if [[ -d skins/portals/custom ]]; then
  sed -i 's/      volumes:/      volumes:\n      - name: custom-portals-skins\n        persistentVolumeClaim:\n          claimName: custom-portals-skins-pv-claim/g' deployment/ui.yaml
  sed -i 's/        volumeMounts:/        volumeMounts:\n        - mountPath: \/usr\/local\/apache2\/htdocs\/dinsight\/skins\/v2\/custom\n          name: custom-portals-skins/g' deployment/ui.yaml
fi
if [[ -d skins/portals/standard ]]; then
  sed -i 's/      volumes:/      volumes:\n      - name: standard-portals-skins\n        persistentVolumeClaim:\n          claimName: standard-portals-skins-pv-claim/g' deployment/ui.yaml
  sed -i 's/        volumeMounts:/        volumeMounts:\n        - mountPath: \/usr\/local\/apache2\/htdocs\/dinsight\/skins\/v2\/standard\n          name: standard-portals-skins/g' deployment/ui.yaml
fi
if [[ -d skins/data-preparation/standard ]]; then
  sed -i 's/      volumes:/      volumes:\n      - name: standard-dp-skins\n        persistentVolumeClaim:\n          claimName: standard-dp-skins-pv-claim/g' deployment/ui.yaml
  sed -i 's/        volumeMounts:/        volumeMounts:\n        - mountPath: \/usr\/local\/apache2\/htdocs\/dataprep\/skins\/v2\/standard\n          name: standard-dp-skins/g' deployment/ui.yaml
fi
if [[ -d skins/storyboards/standard ]]; then
  sed -i 's/      volumes:/      volumes:\n      - name: standard-sb-skins\n        persistentVolumeClaim:\n          claimName: standard-sb-skins-pv-claim/g' deployment/ui.yaml
  sed -i 's/        volumeMounts:/        volumeMounts:\n        - mountPath: \/usr\/local\/apache2\/htdocs\/storyboards\/skins\/v2\/standard\n          name: standard-sb-skins/g' deployment/ui.yaml
fi
if [[ -d skins/home/standard ]]; then
  sed -i 's/      volumes:/      volumes:\n      - name: standard-home-skins\n        persistentVolumeClaim:\n          claimName: standard-home-skins-pv-claim/g' deployment/ui.yaml
  sed -i 's/        volumeMounts:/        volumeMounts:\n        - mountPath: \/usr\/local\/apache2\/htdocs\/home\/skins\/standard\n          name: standard-home-skins/g' deployment/ui.yaml
fi
if [[ -d skins/user-access/standard ]]; then
  sed -i 's/      volumes:/      volumes:\n      - name: standard-uam-skins\n        persistentVolumeClaim:\n          claimName: standard-uam-skins-pv-claim/g' deployment/user-access.yaml
  sed -i 's/        volumeMounts:/        volumeMounts:\n        - mountPath: \/opt\/jboss\/keycloak\/themes\/dataclarity-admin\/common\/resources\/skins\/standard\n          name: standard-uam-skins/g' deployment/user-access.yaml
fi

echo ""
read -rp "Disable authentication for the Kubernetes Dashboard (not recommended if you are using a public entry point)? [y/n] (Default: n): " DISABLE_DASHBOARD_AUTH
DISABLE_DASHBOARD_AUTH=${DISABLE_DASHBOARD_AUTH:-"n"}
if [[ ${DISABLE_DASHBOARD_AUTH} = "y" ]]; then
  kubectl patch deployment --namespace=kube-system kubernetes-dashboard --type='json' -p='[{"op": "add", "path": "/spec/template/spec/containers/0/args/-", "value" : "--enable-skip-login" }]'
  echo "Authentication for the Kubernetes Dashboard is disabled."
fi
echo "DISABLE_DASHBOARD_AUTH=${DISABLE_DASHBOARD_AUTH}" >> ../config.txt

echo ""
read -rp "Proceed with the installation? [y/n] (Default: y): " APPLY_NOW
echo ""
APPLY_NOW=${APPLY_NOW:-"y"}
if [[ ${APPLY_NOW} = "y" ]]; then
  if [[ -f registry-auth/gcr/auth-key.json ]]; then
    kubectl create secret docker-registry gcr-auth --docker-server=https://gcr.io --docker-username=_json_key --docker-password="$(cat registry-auth/gcr/auth-key.json)"  --docker-email=distrubution@dataclaritycorp.com --dry-run=client -o yaml | kubectl apply -f -
    kubectl label secret gcr-auth solution=dataclarity-platform --overwrite=true
    kubectl patch serviceaccount default -p '{"imagePullSecrets": [{"name": "gcr-auth"}]}'
  fi

  if [[ -f registry-auth/acr/service-principal-id.txt ]]; then
    kubectl create secret docker-registry acr-auth --docker-server https://dataclarity.azurecr.io --docker-username "$(cat registry-auth/acr/service-principal-id.txt)" --docker-password "$(cat registry-auth/acr/service-principal-password.txt)" --docker-email=distrubution@dataclaritycorp.com --dry-run=client -o yaml | kubectl apply -f -
    kubectl label secret acr-auth  solution=dataclarity-platform --overwrite=true
    kubectl patch serviceaccount default -p '{"imagePullSecrets": [{"name": "acr-auth"}]}'
  fi

  if [[ -f certs/cert.crt && -f certs/cert.key ]]; then
    kubectl create secret tls ssl-certificate --key certs/cert.key --cert certs/cert.crt --dry-run=client -o yaml | kubectl apply -f -
    kubectl patch daemonset --namespace=ingress nginx-ingress-microk8s-controller --type='json' -p='[{"op": "add", "path": "/spec/template/spec/containers/0/args/-", "value" : "--default-ssl-certificate=default/ssl-certificate" }]'
  fi

  if [[ -f deployment/postgres.yaml ]]; then
    kubectl apply -f persistent/postgres.yaml
    kubectl apply -f secret/postgres.yaml
    kubectl apply -f configmap/postgres.yaml
    echo "Waiting for persistent storage..."
    sleep 20s
    kubectl apply -f deployment/postgres.yaml
    kubectl rollout status -w deployment/postgres
  fi

  kubectl apply -f persistent

  if [[   -f persistent/custom-portals-skins.yaml
       || -f persistent/standard-portals-skins.yaml
       || -f persistent/standard-db-skins.yaml
       || -f persistent/standard-sb-skins.yaml
       || -f persistent/standard-home-skins.yaml
       || -f persistent/standard-uam-skins.yaml
     ]] && [[ -d skins ]]; then
    echo ""
	read -rp "Apply provided skins? [y/n]: " APPLY_SKINS
    if [[ ${APPLY_SKINS} = "y" ]]; then
      echo ""
	  echo "Waiting for persistent storage..."
      sleep 20s
      K8S_STORAGE_LOCATION=/var/snap/microk8s/common/default-storage
      if [[ -f persistent/custom-portals-skins.yaml ]]; then
        sudo cp -r skins/portals/custom/. ${K8S_STORAGE_LOCATION}/$(ls ${K8S_STORAGE_LOCATION} | grep custom-portals-skins)
      fi
      if [[ -f persistent/standard-portals-skins.yaml ]]; then
        sudo cp -r skins/portals/standard/. ${K8S_STORAGE_LOCATION}/$(ls ${K8S_STORAGE_LOCATION} | grep standard-portals-skins)
      fi
      if [[ -f persistent/standard-dp-skins.yaml ]]; then
        sudo cp -r skins/data-preparation/standard/. ${K8S_STORAGE_LOCATION}/$(ls ${K8S_STORAGE_LOCATION} | grep standard-dp-skins)
      fi
      if [[ -f persistent/standard-sb-skins.yaml ]]; then
        sudo cp -r skins/storyboards/standard/. ${K8S_STORAGE_LOCATION}/$(ls ${K8S_STORAGE_LOCATION} | grep standard-sb-skins)
      fi
      if [[ -f persistent/standard-home-skins.yaml ]]; then
        sudo cp -r skins/home/standard/. ${K8S_STORAGE_LOCATION}/$(ls ${K8S_STORAGE_LOCATION} | grep standard-home-skins)
      fi
      if [[ -f persistent/standard-uam-skins.yaml ]]; then
        sudo cp -r skins/user-access/standard/. ${K8S_STORAGE_LOCATION}/$(ls ${K8S_STORAGE_LOCATION} | grep standard-uam-skins)
      fi
    fi
  fi

  kubectl apply -f secret
  kubectl apply -f configmap
  kubectl apply -f deployment
  kubectl apply -f ingress

  kubectl get deployments -o=name | while read -r x; do kubectl rollout status -w $x --timeout=20m; done
  echo ""
  echo "Installation successful."
  echo ""
  
  if [[ ${DISABLE_DASHBOARD_AUTH} = "n" ]]; then
	  echo "Kubernetes dashboard access token:"
	  token=$(microk8s kubectl -n kube-system get secret | grep default-token | cut -d " " -f1)
	  microk8s kubectl -n kube-system describe secret "$token" | grep "token:" | sed 's/^.* //'
  fi

  protocol="https://"

  if [[ ${DISABLE_HTTPS} = "y" ]]; then
	protocol="http://"
  fi
  echo ""
  echo "You can access the DataClarity homepage here: ${protocol}${PUBLIC_ENTRYPOINT}/home"
  echo "The default credentials for the dataclarity realm are: admin/admin"
  if [[ ${DCPWD} = true ]]; then
  echo "The credentials for the master realm are: dcadmin/${KP}. Please save these credentials in your password manager of choice."
  fi
  echo "The installation input values have been saved in the config.txt file."
  echo ""
  echo "Go to https://support.dataclaritycorp.com to learn more about the platform and read the how-to guidelines."
  echo ""
fi

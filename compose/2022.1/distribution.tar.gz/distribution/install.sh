#!/usr/bin/env bash

WORKING_DIR=compose

rm -rf ${WORKING_DIR}
mkdir ${WORKING_DIR}

cp -r template/. ${WORKING_DIR}

cd ${WORKING_DIR}

mkdir -p ./assets/certs/dc
mkdir -p ./assets/certs/ds
mkdir -p ./assets/certs/uam
mkdir -p ./assets/certs/data

# IP=$(ip route get 8.8.8.8 | grep -oP 'src \K[^ ]+')
HOST=$(hostname)

replace_text() {
  find . -type f -exec sed -i "s/$1/$2/g" {} +
}
replace_variable() {
  replace_text "\$$1" $2
}

echo
if [[ -z ${1} ]]; then
  read -p "Select the software version [production, beta] (Default: production) : " CHANNEL
else
  CHANNEL=${1}
fi
if [[ ${CHANNEL} = "beta" ]]; then
  replace_variable IMAGE_TAG "latest-2022.1-release"
else
  replace_variable IMAGE_TAG "latest-2022.1"
fi

echo
if [[ -z ${2} ]]; then
  # read -p "Public entry point (ip address or domain name) (Default: ${IP}) : " PUBLIC_ENTRYPOINT
  read -p "Public entry point (ip address or domain name) (Default: ${HOST}) : " PUBLIC_ENTRYPOINT
  # PUBLIC_ENTRYPOINT=${PUBLIC_ENTRYPOINT:-$IP}
  PUBLIC_ENTRYPOINT=${PUBLIC_ENTRYPOINT:-$HOST}
else
  PUBLIC_ENTRYPOINT=${2}
fi

echo
if [[ -z ${3} ]]; then
  read -p "Setup SSL (Secure Sockets Layer) [y/n] (Default: n) : " ENABLE_SSL
else
  ENABLE_SSL=${3}
fi
if [[ ${ENABLE_SSL} == "y" ]]; then
  replace_text '=http:\/\/$PUBLIC_ENTRYPOINT' '=https:\/\/$PUBLIC_ENTRYPOINT'
  replace_text '"http:\/\/$PUBLIC_ENTRYPOINT' '"https:\/\/$PUBLIC_ENTRYPOINT'
  replace_text ': http:\/\/$PUBLIC_ENTRYPOINT' ': https:\/\/$PUBLIC_ENTRYPOINT'
  rm assets/config/load-balancer/nginx.conf
  mv assets/config/load-balancer/ssl/nginx.conf assets/config/load-balancer/nginx.conf
  replace_variable DATASERVER_SSL_ENABLED "true"
  if [[ ! -f assets/certs/cert.crt ]]; then
    echo "No SSL Certificate provided. Creating Self-Signed SSL Certificate..."
    if [[ ${PUBLIC_ENTRYPOINT} =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
      CERT_SAN="IP:$PUBLIC_ENTRYPOINT"
    else
      CERT_SAN="DNS:$PUBLIC_ENTRYPOINT"
    fi
    openssl req -x509 -nodes -days 36500 -newkey rsa:2048 -subj "/CN=$PUBLIC_ENTRYPOINT" --addext "subjectAltName=$CERT_SAN" -keyout assets/certs/dc/cert.key -out assets/certs/dc/cert.crt
  fi
  if [[ ! -f assets/certs/ds/data-server-keystore.jks ]]; then
    KEYSTORE_PASS=$(cat /dev/urandom | tr -dc 'a-zA-Z0-9' | fold -w 32 | head -n 1)
    echo -n "${KEYSTORE_PASS}" > assets/certs/ds/data-server-keystore.pass
    openssl pkcs12 -export -in assets/certs/dc/cert.crt -inkey assets/certs/dc/cert.key -name "data-server" -out assets/certs/ds/cert.p12 -passout pass:${KEYSTORE_PASS}
    docker run -t --rm -v $(pwd)/assets/certs/ds:/opt/ssl-cert-gen/certs openjdk:8-jdk-alpine \
        sh -c "keytool -importkeystore -noprompt \
               -srckeystore /opt/ssl-cert-gen/certs/cert.p12 -srcstoretype pkcs12 -srcstorepass ${KEYSTORE_PASS} \
               -destkeystore /opt/ssl-cert-gen/certs/data-server-keystore.jks -deststoretype pkcs12 -destkeypass ${KEYSTORE_PASS} \
               -storepass ${KEYSTORE_PASS}"
    rm assets/certs/ds/cert.p12
  fi
else
  rm -r assets/certs
  sed -i ':a;N;$!ba;s/      - "443:443"\n//g' docker-compose.yml
  sed -i ':a;N;$!ba;s/      - .\/assets\/certs\/data-server-keystore.jks:\/opt\/dc-data-server\/keystore.jks\n//g' docker-compose.yml
  sed -i ':a;N;$!ba;s/      - .\/assets\/certs\/data-server-keystore.pass:\/opt\/dc-data-server\/keystore.pass\n//g' docker-compose.yml
  replace_variable DATASERVER_SSL_ENABLED "false"
fi
rm -r assets/config/load-balancer/ssl

replace_variable PUBLIC_ENTRYPOINT ${PUBLIC_ENTRYPOINT}
replace_variable DATASERVER_PUBLIC_ENTRYPOINT ${PUBLIC_ENTRYPOINT}

wait_for() {
  RETRIES=150
  echo "Waiting for $1 service..."
  until [[ $(docker-compose exec -T $1 curl -s -o /dev/null -w %{http_code} http://$1:$2$3) == "200" || ${RETRIES} -eq 0 ]]; do
    echo -n '.'
    ((RETRIES--))
    sleep 1
  done
  if [[ ${RETRIES} == 0 ]]; then
    echo "Timed out."
  else
    echo "Service $1 is ready."
  fi
}

wait_for_postgres() {
  RETRIES=20
  echo "Waiting for postgres server..."
  until docker-compose exec -T postgres psql -U postgres -c '\q' > /dev/null 2>&1 || [[ ${RETRIES} -eq 0 ]]; do
    echo -n '.'
    ((RETRIES--))
    sleep 1
  done
  if [[ ${RETRIES} == 0 ]]; then
    echo "Timed out."
  else
    echo "Postgres is ready."
  fi
}

echo
if [[ -z ${3} ]]; then
  read -p "Deploy to Docker now [y/n] (Default: n) : " APPLY_NOW
else
  APPLY_NOW=${4}
fi
if [[ ${APPLY_NOW} == "y" ]]; then
  if [[ -f assets/registry-auth/gcr/auth-key.json ]]; then
    echo "Image registry logging in..."
    cat assets/registry-auth/gcr/auth-key.json | docker login -u _json_key --password-stdin https://gcr.io
  fi

  echo "Creating data volumes..."
  docker volume create pgdata
  docker volume create zkdata
  docker volume create zklogs
  docker volume create drill-dfs
  docker volume create screenshots-storage
  docker-compose up -d postgres
  wait_for_postgres

  docker-compose up -d user-access
  wait_for "user-access" 8080 "/auth/"

  docker-compose up -d load-balancer
  
  docker-compose exec -T storyboards apk --no-cache add curl
  wait_for "storyboards" 8080 "/sb/actuator/health/"

  docker-compose up -d data-server
  docker-compose exec -T data-server apk --no-cache add curl
  wait_for "data-server" 8080 "/"

  docker-compose up -d

  docker-compose exec -T notification apk --no-cache add curl
  wait_for "notification" 8080 "/notification/actuator/health"

  docker-compose exec -T screenshot-engine apk --no-cache add curl
  wait_for "screenshot-engine" 8090 "/actuator/health/"

  docker-compose ps

  echo "Installation finished."
fi

##Using your certificates

The DataClarity installer generates a self-signed certificate during the installation, if one is not available.
You can use your own certificate for the Dataclarity load balancer as well; simply copy the certificate and key files, in /dataclarity/template/assets/certs/dc, and rename the certificate to cert.crt and the key file to cert.key.

The DataClarity applications are Java based; thus, in order for them to be able to communicate with other secure applications using TLS, the certificate for these 3rd party applications must be imported into the DataClarity keystores.

Certificates needed by the User Access application (in order to communicate with a secure identity provider server, for example), must be copied over here (only the certificate file): 
/dataclarity/template/assets/certs/uam.

Certificates needed by the rest of the DataClarity applications (in order to communicate with secure database servers, for example), must be copied over here (only the certificate file): 
/dataclarity/template/assets/certs/data.

Copying new certificates after the initial installation, will require that you run the install.sh script again.

## Creating a Self-Signed SSL Certificate

You can create a self-signed certificate yourself, to use it for the load balancer, using this command (place the files in /dataclarity/template/assets/certs/dc):

```
openssl req -x509 -nodes -days 365 -newkey rsa:2048 -subj "/CN=YOUR_HOST" --addext "subjectAltName=DNS:YOUR_HOST" -keyout cert.key -out cert.crt
```

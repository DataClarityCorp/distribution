## Creating a Self-Signed SSL Certificate
```
openssl req -x509 -nodes -days 365 -newkey rsa:2048 -subj "/CN=YOUR_HOST" --addext "subjectAltName=DNS:YOUR_HOST" -keyout cert.key -out cert.crt
```

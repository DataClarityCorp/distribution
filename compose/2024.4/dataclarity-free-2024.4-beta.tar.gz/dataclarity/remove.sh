#!/usr/bin/env bash

WORKING_DIR=compose

cd ${WORKING_DIR}

docker-compose down

read -p "Remove all the docker volumes, including the PostgreSQL data? [y/n] : " REMOVE_PG_DATA
if [[ ${REMOVE_PG_DATA} = "y" ]]; then
docker volume rm pgdata
docker volume rm zkdata
docker volume rm zklogs
docker volume rm drill-dfs
docker volume rm screenshots-storage
fi

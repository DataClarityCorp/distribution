#!/usr/bin/env bash

if docker compose version 1> /dev/null 2> /dev/null; then
  COMPOSE='docker-compose'
elif docker-compose version 1> /dev/null 2> /dev/null; then
  COMPOSE='docker compose'
else
  echo "Docker Compose is not installed. Docker and Docker Compose are required."
  exit 1
fi

WORKING_DIR=compose

rm -rf ${WORKING_DIR}
mkdir ${WORKING_DIR}

cp -r template/. ${WORKING_DIR}

cd ${WORKING_DIR}

HOST=$(hostname)
KP=$(openssl rand -base64 12)
sed -i "$ a KEYCLOAK_PASSWORD=${KP}" .env

replace_text() {
  find . -type f -exec sed -i "s/$1/$2/g" {} +
}
replace_variable() {
  replace_text "\$$1" $2
}

replace_variable IMAGE_TAG "latest-2024.1"

echo
if [[ -z ${2} ]]; then
  read -p "Enter the public entry point (IP, host, domain, etc) (Default: ${HOST}): : " PUBLIC_ENTRYPOINT
  PUBLIC_ENTRYPOINT=${PUBLIC_ENTRYPOINT:-$HOST}
else
  PUBLIC_ENTRYPOINT=${2}
fi

  replace_text '=http:\/\/$PUBLIC_ENTRYPOINT' '=https:\/\/$PUBLIC_ENTRYPOINT'
  replace_text '"http:\/\/$PUBLIC_ENTRYPOINT' '"https:\/\/$PUBLIC_ENTRYPOINT'
  replace_text ': http:\/\/$PUBLIC_ENTRYPOINT' ': https:\/\/$PUBLIC_ENTRYPOINT'
  replace_text 'http:\/\/{host}' 'https:\/\/{host}'
  rm assets/config/load-balancer/nginx.conf
  mv assets/config/load-balancer/ssl/nginx.conf assets/config/load-balancer/nginx.conf
  rm -r assets/config/load-balancer/ssl
  if [[ ! -f assets/certs/dc/cert.crt ]]; then
    echo "No SSL Certificate provided. Creating Self-Signed SSL Certificate..."
    if [[ ${PUBLIC_ENTRYPOINT} =~ ^[0-9]+\.[0-9]+\.[0-9]+\.[0-9]+$ ]]; then
      CERT_SAN="IP:$PUBLIC_ENTRYPOINT"
    else
      CERT_SAN="DNS:$PUBLIC_ENTRYPOINT"
    fi
    openssl req -x509 -nodes -days 36500 -newkey rsa:2048 -subj "/CN=$PUBLIC_ENTRYPOINT" --addext "subjectAltName=$CERT_SAN" -keyout assets/certs/dc/cert.key -out assets/certs/dc/cert.crt
  fi

replace_variable PUBLIC_ENTRYPOINT ${PUBLIC_ENTRYPOINT}

wait_for() {
  RETRIES=150
  echo "Waiting for $1 service..."
  until [[ $($COMPOSE exec -T $1 curl -s -o /dev/null -w %{http_code} http://$1:$2$3) == "200" || ${RETRIES} -eq 0 ]]; do
    echo -n '.'
    ((RETRIES--))
    sleep 1
  done
  if [[ ${RETRIES} == 0 ]]; then
    echo "Timed out."
  else
    echo "Service $1 is ready."
  fi
}

wait_for_postgres() {
  RETRIES=20
  echo "Waiting for postgres server..."
  until $COMPOSE exec -T postgres psql -U postgres -c '\q' > /dev/null 2>&1 || [[ ${RETRIES} -eq 0 ]]; do
    echo -n '.'
    ((RETRIES--))
    sleep 1
  done
  if [[ ${RETRIES} == 0 ]]; then
    echo "Timed out."
  else
    echo "Postgres is ready."
  fi
}

echo
if [[ -z ${3} ]]; then
  read -p "Install DataClarity now? [y/n] (Default: y) : " APPLY_NOW
else
  APPLY_NOW=${4}
fi
APPLY_NOW=${APPLY_NOW:-"y"}
if [[ ${APPLY_NOW} == "y" ]]; then
  if [[ -f assets/registry-auth/gcr/auth-key.json ]]; then
    echo "Image registry logging in..."
    cat assets/registry-auth/gcr/auth-key.json | docker login -u _json_key --password-stdin https://gcr.io
  fi

  echo "Creating data volumes..."
  docker volume create pgdata
  docker volume create zkdata
  docker volume create zklogs
  docker volume create drill-dfs
  docker volume create screenshots-storage
  $COMPOSE up -d postgres
  wait_for_postgres

  $COMPOSE up -d user-access
  wait_for "user-access" 8080 "/auth/"

  $COMPOSE up -d load-balancer
  
  $COMPOSE exec -T storyboards apk --no-cache add curl
  wait_for "storyboards" 8080 "/sb/actuator/health/"

  $COMPOSE up -d

  $COMPOSE exec -T notification apk --no-cache add curl
  wait_for "notification" 8080 "/notification/actuator/health"

  $COMPOSE exec -T screenshot-engine apk --no-cache add curl
  wait_for "screenshot-engine" 8090 "/actuator/health/"

  $COMPOSE ps

  echo ""
  echo "Installation successful."
  echo "You can access the DataClarity homepage here: https://${PUBLIC_ENTRYPOINT}/home"
  echo "The default credentials for the dataclarity realm are: admin/admin"
  echo ""
  echo "Go to https://support.dataclaritycorp.com to learn more about the platform and read the how-to guidelines."
fi

#!/bin/bash

MIN_CPU_NUMBER=8
MIN_RAM_SIZE=31
MIN_FREE_DISK_SPACE=95
OSID=$(cat /etc/os-release | grep "ID" -m1)

if [[ $EUID -ne 0 ]]; then
   echo "This script must be run as root."
   exit 1
fi

NO_ERROR=true

CPU_NUMBER=$(nproc)
if [[ $CPU_NUMBER -lt $MIN_CPU_NUMBER ]]
then
  echo 'Insufficient number of CPUs.'
  NO_ERROR=false
fi

RAM_SIZE=$(printf "%.0f" "$(grep MemTotal /proc/meminfo | awk '{print $2/1024^2}')")
if [[ $RAM_SIZE -lt $MIN_RAM_SIZE ]]
then
  echo 'Insufficient RAM size.'
  NO_ERROR=false
fi

FREE_DISK_SPACE=$(printf "%.0f" "$(df /var/lib/docker | awk 'FNR==2{print $4/1024^2}')")
if [[ $FREE_DISK_SPACE -lt $MIN_FREE_DISK_SPACE ]]
then
  echo 'Insufficient free disk space for /var/lib/docker.'
  NO_ERROR=false
fi

function check_port() {
  PORT=$1
  if [ "$OSID" = 'ID="rhel"' ] || [ "$OSID" = 'ID="centos"' ]; then
    PORT_USAGE=$(ss -nutlp | grep "$PORT")
  else
    PORT_USAGE=$(lsof -i:"$PORT" | grep LISTEN)
  fi
  if [[ -n $PORT_USAGE ]]
then
  echo "Port $PORT is already in use."
  NO_ERROR=false
fi
}

check_port 80
check_port 443
check_port 5432

function check_host() {
  HOST=$1

  ping -c 1 "$HOST" 2>&1 > /dev/null
  PING_RESULT=$(echo $?)

  if [[ $PING_RESULT -ne 0 ]]
  then
    echo "Host $HOST is not reachable."
    NO_ERROR=false
  fi
}

check_host "api.snapcraft.io"
#check_host "auth.docker.io"
#check_host "fastly.cdn.snapcraft.io"
check_host "gcr.io"
check_host "googlecode.l.googleusercontent.com"
check_host "k8s.gcr.io"
check_host "production.cloudflare.docker.com"
#check_host "quay.io"
#check_host "registry-1.docker.io"
check_host "storage.googleapis.com"

if [[ $NO_ERROR == true ]]
then
  echo 'Validation successfully passed.'
fi

#!/usr/bin/env bash

WORKING_DIR=compose

cd ${WORKING_DIR}

docker-compose down

read -p "Remove postgres data [y/n] : " REMOVE_PG_DATA
if [[ ${REMOVE_PG_DATA} = "y" ]]; then
docker volume rm pgdata
docker volume rm screenshots-storage
fi
